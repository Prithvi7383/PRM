package com.product.productRetailManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductRetailManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
