package com.product.productRetailManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductRetailManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductRetailManagementApplication.class, args);
	}

}
